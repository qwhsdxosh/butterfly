const buttefly = document.getElementByld("butterfly");
const wood = document.getElementByld("wood");

document.addEventListener("keydown", function(event) {
    jump()
});

function jump () {
    if (butterfly.classList !="jump") {
        butterlfy.classList.add("jump")
    }   
    setTimeout( function() {
        butterlfy.classList.remove("jump")
    }, 300)
}

let isAlive = setInterval (function() {
   let butteflyTop = parsInt(window.getComputedStyle(buttefly).getPropertyValue("top"));
   let woodLeft = parsInt(window.getComputedStyle(wood).getPropertyValue("left"));

   if (woodLeft < 50 && woodLeft> 0 && butteflyTop >= 140) {
        alert("GAME OVER! !")
   }
}, 10)